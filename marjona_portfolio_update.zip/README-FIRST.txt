MARJONA PORTFOLIO UPDATE

Files included:
- index.html: updated portfolio page, with project cards loaded from content/projects.json
- .pages.yml: configuration for Pages CMS visual editor
- content/projects.json: starter project list
- media/: upload images, video files, and documents here through Pages CMS

IMPORTANT:
1. Upload these files into the ROOT of your existing GitHub repository, preserving the content/ and media/ folders.
2. This updates your current index.html. Keep a copy of your old one as a backup before replacing it.
3. To visually edit projects, visit https://app.pagescms.org, sign in with GitHub, grant access only to your portfolio repository, and create/edit entries in Portfolio Projects.
4. This is a static GitHub Pages site. CMS edits save files to GitHub; GitHub Pages will then publish the changed site.
5. The portrait image path currently expects media/portrait.jpg. Upload a portrait with that filename or change the path in index.html.
6. Replace YOUR_EMAIL_HERE and the Instagram/YouTube links before publishing.
7. Do not upload private information, passwords, or API keys.
